import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import Services from "@/components/Services";
import FeaturedProperties from "@/components/FeaturedProperties";
import About from "@/components/About";
import Testimonials from "@/components/Testimonials";
import Contact from "@/components/Contact";
import Footer from "@/components/Footer";
import WhatsAppFloat from "@/components/WhatsAppFloat";

const Index = () => (
  <>
    <Navbar />
    <Hero />
    <FeaturedProperties />
    <Services />
    <About />
    <Testimonials />
    <Contact />
    <Footer />
    <WhatsAppFloat />
  </>
);

export default Index;
