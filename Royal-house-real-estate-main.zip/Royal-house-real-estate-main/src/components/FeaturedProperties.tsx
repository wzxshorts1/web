import { motion } from "framer-motion";
import { Bed, Bath, Maximize, MessageCircle } from "lucide-react";
import property1 from "@/assets/property-1.jpg";
import property2 from "@/assets/property-2.jpg";
import property3 from "@/assets/property-3.jpg";

const properties = [
  {
    img: property1,
    title: "Al Majaz Waterfront Apartment",
    location: "Al Majaz, Sharjah",
    price: "AED 1,200,000",
    beds: 3,
    baths: 2,
    sqft: "1,850",
    tag: "For Sale",
  },
  {
    img: property2,
    title: "Beachfront Villa with Pool",
    location: "Al Khan, Sharjah",
    price: "AED 85,000/yr",
    beds: 5,
    baths: 4,
    sqft: "4,200",
    tag: "For Rent",
  },
  {
    img: property3,
    title: "Luxury Penthouse Suite",
    location: "Corniche, Sharjah",
    price: "AED 3,500,000",
    beds: 4,
    baths: 3,
    sqft: "3,100",
    tag: "For Sale",
  },
];

const FeaturedProperties = () => (
  <section id="properties" className="py-24">
    <div className="container mx-auto px-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="text-center mb-16"
      >
        <span className="text-primary text-sm font-semibold tracking-widest uppercase">Featured Listings</span>
        <h2 className="font-heading text-4xl md:text-5xl font-bold mt-3 mb-4">Premium Properties</h2>
        <p className="text-muted-foreground max-w-xl mx-auto">
          Handpicked properties in prime Sharjah locations
        </p>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {properties.map((p, i) => (
          <motion.div
            key={p.title}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.15 }}
            className="group bg-card border border-border rounded-sm overflow-hidden hover:border-primary/40 transition-all duration-300 hover:shadow-[var(--shadow-gold)]"
          >
            <div className="relative overflow-hidden h-64">
              <img
                src={p.img}
                alt={p.title}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              />
              <span className="absolute top-4 left-4 bg-primary text-primary-foreground text-xs font-bold px-3 py-1 rounded-sm tracking-wider uppercase">
                {p.tag}
              </span>
            </div>
            <div className="p-6">
              <div className="text-primary font-heading text-xl font-bold mb-1">{p.price}</div>
              <h3 className="font-heading text-lg font-semibold mb-1">{p.title}</h3>
              <p className="text-sm text-muted-foreground mb-4">{p.location}</p>
              <div className="flex items-center gap-4 text-sm text-muted-foreground mb-5 border-t border-border pt-4">
                <span className="flex items-center gap-1"><Bed className="w-4 h-4" /> {p.beds}</span>
                <span className="flex items-center gap-1"><Bath className="w-4 h-4" /> {p.baths}</span>
                <span className="flex items-center gap-1"><Maximize className="w-4 h-4" /> {p.sqft} sqft</span>
              </div>
              <a
                href={`https://wa.me/971507599710?text=I'm interested in: ${encodeURIComponent(p.title)}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-2 w-full bg-primary text-primary-foreground py-3 rounded-sm text-sm font-semibold hover:opacity-90 transition-opacity"
              >
                <MessageCircle className="w-4 h-4" />
                Inquire Now
              </a>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default FeaturedProperties;
