import { motion } from "framer-motion";
import { CheckCircle2 } from "lucide-react";

const highlights = [
  "Licensed and regulated by Sharjah RERA",
  "Multilingual team — Arabic, English, Hindi, Urdu",
  "Comprehensive property management solutions",
  "Transparent pricing with no hidden fees",
  "24/7 client support and emergency maintenance",
  "Extensive network of developers and investors",
];

const About = () => (
  <section id="about" className="py-24 bg-secondary/30">
    <div className="container mx-auto px-4">
      <div className="grid md:grid-cols-2 gap-16 items-center">
        <motion.div
          initial={{ opacity: 0, x: -30 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
        >
          <span className="text-primary text-sm font-semibold tracking-widest uppercase">About Us</span>
          <h2 className="font-heading text-4xl md:text-5xl font-bold mt-3 mb-6">
            Trusted Real Estate Partner in Sharjah
          </h2>
          <p className="text-muted-foreground leading-relaxed mb-8">
            Royal House Real Estate has been serving the Sharjah community with dedication and 
            professionalism. From luxury villas to commercial spaces, we provide end-to-end 
            real estate solutions backed by deep market knowledge and a client-first approach.
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {highlights.map((h) => (
              <div key={h} className="flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-primary mt-0.5 shrink-0" />
                <span className="text-sm text-foreground">{h}</span>
              </div>
            ))}
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 30 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          className="relative"
        >
          <div className="bg-card border border-border rounded-sm p-10 text-center">
            <div className="font-heading text-6xl font-bold text-primary mb-2">15+</div>
            <div className="text-lg text-foreground font-medium mb-1">Years in the Market</div>
            <div className="text-sm text-muted-foreground mb-8">Serving Sharjah & the UAE since day one</div>
            
            <div className="grid grid-cols-3 gap-6 border-t border-border pt-8">
              {[
                { val: "500+", label: "Properties" },
                { val: "1000+", label: "Happy Clients" },
                { val: "50+", label: "Team Members" },
              ].map((s) => (
                <div key={s.label}>
                  <div className="font-heading text-2xl font-bold text-primary">{s.val}</div>
                  <div className="text-xs text-muted-foreground mt-1">{s.label}</div>
                </div>
              ))}
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  </section>
);

export default About;
