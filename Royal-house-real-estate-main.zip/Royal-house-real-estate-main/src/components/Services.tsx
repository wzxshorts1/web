import { motion } from "framer-motion";
import { Building2, Home, Key, TrendingUp, Hammer, Shield, Landmark, Users } from "lucide-react";

const services = [
  { icon: Building2, title: "Property Sales", desc: "Residential & commercial properties across Sharjah and UAE" },
  { icon: Key, title: "Property Rentals", desc: "Short-term and long-term rental solutions for every need" },
  { icon: TrendingUp, title: "Investment Management", desc: "Maximize returns with expert property investment guidance" },
  { icon: Home, title: "Property Management", desc: "Full-service management for homeowners and associations" },
  { icon: Landmark, title: "Luxury Properties", desc: "Exclusive beachfront villas and premium developments" },
  { icon: Hammer, title: "Renovation Services", desc: "Interior design, flooring, electrical, and plumbing" },
  { icon: Shield, title: "Property Valuation", desc: "Accurate market assessments for buying and selling" },
  { icon: Users, title: "Tenant Management", desc: "Screening, rent collection, and tenant relations" },
];

const Services = () => (
  <section id="services" className="py-24 bg-secondary/30">
    <div className="container mx-auto px-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="text-center mb-16"
      >
        <span className="text-primary text-sm font-semibold tracking-widest uppercase">What We Offer</span>
        <h2 className="font-heading text-4xl md:text-5xl font-bold mt-3 mb-4">Our Services</h2>
        <p className="text-muted-foreground max-w-xl mx-auto">
          Comprehensive real estate solutions tailored to the UAE market
        </p>
      </motion.div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {services.map((s, i) => (
          <motion.div
            key={s.title}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.08 }}
            className="group bg-card border border-border rounded-sm p-6 hover:border-primary/40 transition-all duration-300 hover:shadow-[var(--shadow-gold)]"
          >
            <s.icon className="w-10 h-10 text-primary mb-4 group-hover:scale-110 transition-transform" />
            <h3 className="font-heading text-lg font-semibold mb-2">{s.title}</h3>
            <p className="text-sm text-muted-foreground leading-relaxed">{s.desc}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default Services;
