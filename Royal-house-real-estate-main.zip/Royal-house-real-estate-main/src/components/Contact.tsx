import { motion } from "framer-motion";
import { Phone, MessageCircle, MapPin, Clock, Mail } from "lucide-react";

const Contact = () => (
  <section id="contact" className="py-24 bg-secondary/30">
    <div className="container mx-auto px-4">
      <div className="grid md:grid-cols-2 gap-16">
        <motion.div
          initial={{ opacity: 0, x: -30 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
        >
          <span className="text-primary text-sm font-semibold tracking-widest uppercase">Get In Touch</span>
          <h2 className="font-heading text-4xl md:text-5xl font-bold mt-3 mb-6">
            Ready to Find Your Perfect Property?
          </h2>
          <p className="text-muted-foreground leading-relaxed mb-10">
            Whether you're buying, selling, or investing — our team is ready to help. 
            Reach out today for a free consultation.
          </p>

          <div className="space-y-6">
            {[
              { icon: Phone, label: "Call Us", value: "050 759 9710", href: "tel:+971507599710" },
              { icon: MessageCircle, label: "WhatsApp", value: "Send a message", href: "https://wa.me/971507599710" },
              { icon: Mail, label: "Email", value: "info@royalhousere.com", href: "mailto:info@royalhousere.com" },
              { icon: MapPin, label: "Location", value: "Buheira Corniche Road, Al Majaz 3, Sharjah", href: "https://maps.google.com/?q=Buheira+Corniche+Road+Al+Majaz+3+Sharjah" },
              { icon: Clock, label: "Working Hours", value: "Sun–Thu: 10 AM – 7 PM | Sat: 10 AM – 3 PM", href: undefined },
            ].map((item) => (
              <div key={item.label} className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-sm bg-primary/10 flex items-center justify-center shrink-0">
                  <item.icon className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <div className="text-sm text-muted-foreground mb-1">{item.label}</div>
                  {item.href ? (
                    <a href={item.href} target="_blank" rel="noopener noreferrer" className="text-foreground font-medium hover:text-primary transition-colors">
                      {item.value}
                    </a>
                  ) : (
                    <span className="text-foreground font-medium">{item.value}</span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 30 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          className="rounded-sm overflow-hidden border border-border h-[400px] md:h-auto"
        >
          <iframe
            title="Royal House Location"
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3606.6!2d55.389!3d25.339!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2sBuheira+Corniche+Road+Al+Majaz+Sharjah!5e0!3m2!1sen!2sae!4v1"
            width="100%"
            height="100%"
            style={{ border: 0, minHeight: 400 }}
            allowFullScreen
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
          />
        </motion.div>
      </div>
    </div>
  </section>
);

export default Contact;
