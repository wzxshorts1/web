import logo from "@/assets/logo.png";

const Footer = () => (
  <footer className="bg-card border-t border-border py-12">
    <div className="container mx-auto px-4">
      <div className="flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="flex items-center gap-3">
          <img src={logo} alt="Royal House" className="h-10 w-10 object-contain" />
          <div>
            <span className="font-heading text-base font-semibold text-primary">Royal House Real Estate</span>
            <p className="text-xs text-muted-foreground">Buheira Corniche Road, Al Majaz 3, Sharjah</p>
          </div>
        </div>
        <p className="text-sm text-muted-foreground">
          © {new Date().getFullYear()} Royal House Real Estate. All rights reserved.
        </p>
      </div>
    </div>
  </footer>
);

export default Footer;
