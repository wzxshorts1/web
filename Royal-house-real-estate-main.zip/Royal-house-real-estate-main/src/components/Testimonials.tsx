import { motion } from "framer-motion";
import { Star, Quote } from "lucide-react";

const reviews = [
  {
    name: "Ahmed Al-Rashid",
    text: "Royal House found us our dream apartment on the Corniche within two weeks. Professional, responsive, and truly understand the Sharjah market.",
    rating: 5,
  },
  {
    name: "Priya Sharma",
    text: "Their property management service is exceptional. They handle everything from maintenance to tenant relations, making my investment stress-free.",
    rating: 5,
  },
  {
    name: "Mohamed Hassan",
    text: "Sold my villa through Royal House and got above asking price. Their market knowledge and negotiation skills are outstanding.",
    rating: 4,
  },
];

const Testimonials = () => (
  <section className="py-24">
    <div className="container mx-auto px-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="text-center mb-16"
      >
        <span className="text-primary text-sm font-semibold tracking-widest uppercase">Testimonials</span>
        <h2 className="font-heading text-4xl md:text-5xl font-bold mt-3 mb-4">What Our Clients Say</h2>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {reviews.map((r, i) => (
          <motion.div
            key={r.name}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.12 }}
            className="bg-card border border-border rounded-sm p-8 relative"
          >
            <Quote className="w-8 h-8 text-primary/20 absolute top-6 right-6" />
            <div className="flex gap-1 mb-4">
              {[...Array(5)].map((_, j) => (
                <Star key={j} className={`w-4 h-4 ${j < r.rating ? "fill-primary text-primary" : "text-muted"}`} />
              ))}
            </div>
            <p className="text-foreground leading-relaxed mb-6">"{r.text}"</p>
            <div className="font-heading font-semibold text-foreground">{r.name}</div>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default Testimonials;
